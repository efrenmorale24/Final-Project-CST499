<nav class="navbar">
  /user_system/Landing.phpHome</a>
  <?php if (!empty($_SESSION['user_id'])): ?>
    /user_system/class_register.phpClasses</a>
    <user_system/actions.php?action=logoutLogout</a>
  <?php else: ?>
    /user_system/login.phpLogin</a>
    <a href="/user_system/register.php/a>
  <?php endif; ?>
</nav>
