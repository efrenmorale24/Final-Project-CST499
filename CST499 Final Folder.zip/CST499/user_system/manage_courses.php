
<?php
// manage_courses.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$msg = "";
$err = "";

// Handle Add Course
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add'])) {
    $code = trim($_POST['code'] ?? "");
    $title = trim($_POST['title'] ?? "");
    $credits = intval($_POST['credits'] ?? 0);
    $active = isset($_POST['active']) ? 1 : 0;

    if ($code === "" || $title === "" || $credits <= 0) {
        $err = "Code, title, and positive credits are required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO courses (code, title, credits, active) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssii", $code, $title, $credits, $active);
        if ($stmt->execute()) {
            $msg = "Course added successfully.";
        } else {
            $err = "Error: " . $conn->error;
        }
        $stmt->close();
    }
}

// Handle Delete Course
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM courses WHERE id=$id");
    header("Location: manage_courses.php");
    exit;
}

// Fetch Courses
$courses = $conn->query("SELECT * FROM courses ORDER BY code");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Courses</title>
<style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; padding: 20px; }
    h2 { color: #333; }
    form { margin-bottom: 20px; }
    input, button { margin: 5px; padding: 8px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
    th { background: #007bff; color: #fff; }
    a.delete-link { color: #dc3545; text-decoration: none; font-weight: bold; }
    a.delete-link:hover { text-decoration: underline; }
    .back-link { margin-top: 20px; display: inline-block; }
</style>
</head>
<body>
<h2>Manage Courses</h2>

<?php
if ($msg) echo "<p style='color:green;'>$msg</p>";
if ($err) echo "<p style='color:red;'>$err</p>";
?>

<form method="POST" action="">
    <input type="text" name="code" placeholder="CST101" required>
    <input type="text" name="title" placeholder="Intro to Programming" required>
    <input type="number" name="credits" placeholder="3" required min="1">
    <label><input type="checkbox" name="active" checked> Active</label>
    <button type="submit" name="add">Add Course</button>
</form>


<table>
    <tr>
        <th>ID</th>
        <th>Code</th>
        <th>Title</th>
        <th>Credits</th>
        <th>Active</th>
        <th>Action</th>
    </tr>
    <?php while ($c = $courses->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $c['id']; ?></td>
        <td><?php echo htmlspecialchars($c['code']); ?></td>
        <td><?php echo htmlspecialchars($c['title']); ?></td>
        <td><?php echo htmlspecialchars($c['credits']); ?></td>
        <td><?php echo $c['active'] ? "Yes" : "No"; ?></td>
        <td>
            <a class="delete-link" href="?k="return confirm('Delete this course?');">Delete</a>
        </td>
    </tr>
    <?php } ?>
</table>

<p class="back-link"><a href.phpBack to Dashboard</a></p>
