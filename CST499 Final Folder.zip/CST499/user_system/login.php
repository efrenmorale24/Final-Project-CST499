
<?php
// login.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$err = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email'] ?? "");
    $password = trim($_POST['password'] ?? "");

    if ($email === "" || $password === "") {
        $err = "Email and password are required.";
    } else {
        // Using plain comparison here because schema shows 'password' column;
        // If you plan to hash, replace with password_verify().
        $stmt = $conn->prepare("SELECT id, username, email, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($user = $res->fetch_assoc()) {
            // Plain text password check — update to password_verify() if you hash.
            if ($password === $user['password']) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header("Location: landing.php");
                exit;
            } else {
                $err = "Invalid credentials.";
            }
        } else {
            $err = "User not found.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
<h2>Login</h2>
<?php if ($err) echo "<p style='color:red;'>$err</p>"; ?>
<form method="POST" action="">
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>
    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>
    <button type="submit">Login</button>
</form>
<p><egister.phpCreate an account</a></p>
</body>
</html>

