
<?php
// register.php (user sign-up)
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$msg = ""; $err = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? "");
    $email = trim($_POST['email'] ?? "");
    $password = trim($_POST['password'] ?? "");

    if ($username === "" || $email === "" || $password === "") {
        $err = "All fields are required.";
    } else {
        // Check duplicate email
        $chk = $conn->prepare("SELECT id FROM users WHERE email=?");
        $chk->bind_param("s", $email);
        $chk->execute();
        $exists = $chk->get_result()->fetch_assoc();
        $chk->close();

        if ($exists) {
            $err = "Email already registered.";
        } else {
            // Insert (plain password now; upgrade to hashing later)
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->bind_param("sss", $username, $email, $password);
            if ($stmt->execute()) {
                $msg = "Account created. You can now log in.";
            } else {
                $err = "Error creating account: " . $conn->error;
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Create Account</title></head>
<body>
<h2>Create Account</h2>
<?php
if ($msg) echo "<p style='color:green;'>$msg</p>";
if ($err) echo "<p style='color:red;'>$err</p>";
?>
<form method="POST" action="">
    <label>Username:</label><br>
    <input type="text" name="username" required><br><br>
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>
    <label>Password:</label><br>
    <input type="password" name="password" required><br><br>
    <button type="submit">Register</button>
</form>
<p>login.phpBack to login</a></p>
</body>
</html>
