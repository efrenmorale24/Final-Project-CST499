
<?php
// class_register.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$user_id = $_SESSION['user_id'];
$msg = ""; $err = "";

// Handle delete from schedule
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // Only allow delete if the record belongs to the logged-in user
    $del = $conn->prepare("DELETE FROM user_courses WHERE id=? AND user_id=?");
    $del->bind_param("ii", $id, $user_id);
    if ($del->execute()) {
        $msg = "Course removed from your schedule.";
    } else {
        $err = "Error deleting course: " . $conn->error;
    }
    $del->close();
}

// Handle registration submit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $course_id = intval($_POST['course_id'] ?? 0);
    $term = trim($_POST['term'] ?? "");
    $notes = trim($_POST['notes'] ?? "");

    if ($course_id <= 0 || $term === "") {
        $err = "Please select a course and provide a term.";
    } else {
        // Prevent duplicate registration for same course & term
        $chk = $conn->prepare("SELECT id FROM user_courses WHERE user_id=? AND course_id=? AND term=?");
        $chk->bind_param("iis", $user_id, $course_id, $term);
        $chk->execute();
        $exists = $chk->get_result()->fetch_assoc();
        $chk->close();

        if ($exists) {
            $err = "You are already registered for this course in the specified term.";
        } else {
            $ins = $conn->prepare("INSERT INTO user_courses (user_id, course_id, term, notes, created_at) VALUES (?, ?, ?, ?, NOW())");
            $ins->bind_param("iiss", $user_id, $course_id, $term, $notes);
            if ($ins->execute()) {
                // Redirect back to avoid form resubmission on refresh (PRG pattern)
                header("Location: class_register.php?success=1");
                exit;
            } else {
                $err = "Registration failed: " . $conn->error;
            }
            $ins->close();
        }
    }
}

// Fetch active courses for dropdown
$courses = $conn->query("SELECT id, code, title, credits FROM courses WHERE active = 1 ORDER BY code");

// Fetch current schedule
$schedule_sql = "
SELECT uc.id, c.code, c.title, c.credits, uc.term, uc.notes
FROM user_courses uc
JOIN courses c ON uc.course_id = c.id
WHERE uc.user_id = {$user_id}
ORDER BY uc.created_at DESC";
$schedule = $conn->query($schedule_sql);

if (isset($_GET['success'])) { $msg = "Class registered successfully!"; }
?>
<!DOCTYPE html>
<html>
<head><title>Class Registration</title></head>
<body>
<h2>Register for a Class</h2>
<?php
if ($msg) echo "<p style='color:green;'>$msg</p>";
if ($err) echo "<p style='color:red;'>$err</p>";
?>
<form method="POST" action="">
    <label>Select Course:</label><br>
    <select name="course_id" required>
        <option value="">-- choose a course --</option>
        <?php while($c = $courses->fetch_assoc()) { ?>
            <option value="<?php echo $c['id']; ?>">
                <?php echo htmlspecialchars($c['code'] . " - " . $c['title'] . " (" . $c['credits'] . " cr)"); ?>
            </option>
        <?php } ?>
    </select><br><br>

    <label>Term:</label><br>
    <input type="text" name="term" placeholder="Fall 2025" required><br><br>

    <label>Notes (optional):</label><br>
    <input type="text" name="notes" placeholder="e.g., online section"><br><br>

    <button type="submit">Register</button>
</form>

<hr>
<h3>My Schedule</h3>
<table border="1" cellpadding="6" cellspacing="0">
    <tr>
        <th>#</th><th>Code</th><th>Title</th><th>Credits</th><th>Term</th><th>Notes</th><th>Action</th>
    </tr>
    <?php if ($schedule && $schedule->num_rows > 0) {
        while($row = $schedule->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['code']); ?></td>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td><?php echo htmlspecialchars($row['credits']); ?></td>
            <td><?php echo htmlspecialchars($row['term']); ?></td>
            <td><?php echo htmlspecialchars($row['notes']); ?></td>
            <td><a href="class_register.php?php echo $row[" onclick="return confirm('Remove this class?');">Delete</a></td>
        </tr>
    <?php } } else { ?>
        <tr><td colspan="7">No classes registered yet.</td></tr>
    <?php } ?>
</table>

<p>landing.phpBack to dashboard</a></p>
</body>
</html>
