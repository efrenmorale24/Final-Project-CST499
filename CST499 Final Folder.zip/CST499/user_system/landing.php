
<?php
// ----------------------
// landing.php (all-in-one)
// ----------------------
//
// TROUBLESHOOTING (dev only):
// Uncomment these two lines to print errors if your server hides them.
// ini_set('display_errors', '1');
// error_reporting(E_ALL);

// Start session if not already started
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// --- Single-file logout handler ---
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Safely end session and redirect back to this page
    session_unset();
    session_destroy();

    // After destroying, start a fresh session so page renders cleanly
    session_start();

    // Redirect to remove the query string from the URL
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

// --- Fake login for testing (optional) ---
// If you want to see a non-Guest name without your auth flow,
// uncomment the next line:
// $_SESSION['username'] = $_SESSION['username'] ?? 'normie';

$username = (!empty($_SESSION['username'])) ? $_SESSION['username'] : 'Guest';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Landing</title>
  <style>
    /* ========================
       Design tokens (edit here)
       ======================== */
    :root {
      --page-bg: #eef1f6;      /* soft gray background */
      --card-bg: #ffffff;      /* card background */
      --text: #1f2937;         /* base text color */
      --heading: #111827;      /* heading color */
      --muted: #6b7280;        /* helper text */
      --primary: #1e70ff;      /* blue button */
      --primary-hover: #175ae0;
      --shadow: 0 6px 24px rgba(0,0,0,0.08);
      --radius: 12px;
    }
    @media (prefers-color-scheme: dark) {
      :root {
        --page-bg: #0b1323;
        --card-bg: #101827;
        --text: #e5e7eb;
        --heading: #f3f4f6;
        --muted: #9aa4b2;
        --primary: #5aa2ff;
        --primary-hover: #3b86f0;
        --shadow: 0 12px 28px rgba(0,0,0,0.35);
      }
    }

    /* Page layout */
    html, body { height: 100%; }
    body {
      margin: 0;
      background: var(--page-bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      display: grid;
      place-items: center; /* center the card */
    }
    .wrap {
      width: min(520px, 92vw);
      padding: 24px 0;
    }

    /* Card with header */
    .card {
      background: var(--card-bg);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      overflow: hidden; /* for header radius */
    }
    .header {
      padding: 16px 20px;
      background: linear-gradient(180deg, rgba(255,255,255,0.65) 0%, rgba(240,243,248,0.65) 100%);
    }
    @media (prefers-color-scheme: dark) {
      .header {
        background: linear-gradient(180deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0.02) 100%);
      }
    }
    .title {
      margin: 0 0 6px;
      font-weight: 700;
      font-size: 20px;
      color: var(--heading);
      text-align: center;
    }
    .small {
      margin: 0;
      font-size: 13px;
      color: var(--muted);
      text-align: center;
      line-height: 1.38;
    }
    .small a {
      color: var(--muted);
      text-decoration: none;
      border-bottom: 1px solid transparent;
    }
    .small a:hover {
      color: var(--text);
      border-bottom-color: rgba(203,213,225,0.8);
    }

    .body {
      padding: 16px 20px;
    }

    /* Actions */
    .actions {
      display: grid;
      grid-template-columns: 1fr;
      gap: 10px;
    }
    .btn {
      display: inline-block;
      width: 100%;               /* full-width blue bar like a CTA */
      text-align: center;
      text-decoration: none;
      border: 0;
      cursor: pointer;
      border-radius: 10px;
      padding: 12px 16px;
      font-size: 14px;
      font-weight: 600;
      transition: transform .06s ease, background .12s ease, box-shadow .12s ease;
      white-space: nowrap;
    }
    .btn-primary {
      color: #fff;
      background: var(--primary);
      box-shadow: 0 4px 10px rgba(30,112,255,0.25);
    }
    .btn-primary:hover { background: var(--primary-hover); }
    .btn-primary:active { transform: translateY(1px); }

    .footer {
      margin-top: 12px;
      text-align: center;
      font-size: 12px;
      color: var(--muted);
    }
  </style>
</head>
<body>
  <main class="wrap" role="main" aria-labelledby="welcome">
    <section class="card">
      <div class="header">
        <h1 id="welcome" class="title">Welcome, <?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></h1>
        <p class="small">
          class/register.phpclass/register.php</a> Register for a Class
        </p>
      </div>

      <div class="body">
        <div class="actions" role="group" aria-label="Primary action">
          <!-- Single-page logout -->
          ?action=logoutLogout</a>
        </div>
      </div>
    </section>

    <p class="footer">© <?php echo date('Y'); ?></p>
  </main>
</body>
</html>
