
  </main>
  <footer class="footer">
    <small>&copy; <?= date('Y') ?> Course Portal</small>
  </footer>
</body>
</html>
