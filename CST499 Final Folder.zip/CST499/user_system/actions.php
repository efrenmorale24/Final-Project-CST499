<?php
session_start();
require __DIR__ . '/db_connect.php';

define('BASE_URL', '/user_system');

// Redirect helper
function redirect($path) {
    header('Location: ' . BASE_URL . $path);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? null;

// ✅ CSRF check for POST actions except login/register
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !in_array($action, ['login', 'register'])) {
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
}

/* -------- Register user -------- */
if ($action === 'register') {
    $username = trim($_POST['username'] ?? '');
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if ($username && $email && $password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        if (!$stmt) die('Prepare failed: ' . $conn->error);
        $stmt->bind_param("sss", $username, $email, $hash);
        if (!$stmt->execute()) die('Execute failed: ' . $stmt->error);

        $_SESSION['flash'] = 'Account created! Please log in.';
        redirect('/login.php');
    } else {
        $_SESSION['flash'] = 'Please fill all fields correctly.';
        redirect('/register.php');
    }
}

/* -------- Login -------- */
if ($action === 'login') {
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();
        $user = $res->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $email;
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate CSRF token
            redirect('/class_register.php');
        } else {
            $_SESSION['flash'] = 'Invalid credentials.';
            redirect('/login.php');
        }
    } else {
        $_SESSION['flash'] = 'Please enter valid email and password.';
        redirect('/login.php');
    }
}

/* -------- Logout -------- */
if ($action === 'logout') {
    session_destroy();
    redirect('/Landing.php');
}

/* -------- Add course to schedule -------- */
if ($action === 'add_course') {
    if (!isset($_SESSION['user_id'])) redirect('/login.php');

    $course_id = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT);
    $term = trim($_POST['term'] ?? 'Spring 2026');
    $notes = trim($_POST['notes'] ?? '');

    if ($course_id) {
        $stmt = $conn->prepare("INSERT IGNORE INTO user_courses (user_id, course_id, term, notes) VALUES (?, ?, ?, ?)");
        if (!$stmt) die('Prepare failed: ' . $conn->error);
        $stmt->bind_param("iiss", $_SESSION['user_id'], $course_id, $term, $notes);
        if (!$stmt->execute()) die('Execute failed: ' . $stmt->error);
    }
    redirect('/class_register.php');
}

/* -------- Update registration -------- */
if ($action === 'update_registration') {
    if (!isset($_SESSION['user_id'])) redirect('/login.php');

    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $term = trim($_POST['term'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if ($id) {
        $stmt = $conn->prepare("UPDATE user_courses SET term = ?, notes = ? WHERE id = ? AND user_id = ?");
        if (!$stmt) die('Prepare failed: ' . $conn->error);
        $stmt->bind_param("ssii", $term, $notes, $id, $_SESSION['user_id']);
        if (!$stmt->execute()) die('Execute failed: ' . $stmt->error);
    }
    redirect('/class_register.php');
}

/* -------- Delete registration -------- */
if ($action === 'delete_registration') {
    if (!isset($_SESSION['user_id'])) redirect('/login.php');

    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $conn->prepare("DELETE FROM user_courses WHERE id = ? AND user_id = ?");
        if (!$stmt) die('Prepare failed: ' . $conn->error);
        $stmt->bind_param("ii", $id, $_SESSION['user_id']);
        if (!$stmt->execute()) die('Execute failed: ' . $stmt->error);
    }
    redirect('/class_register.php');
}

// Default fallback
redirect('/Landing.php');
